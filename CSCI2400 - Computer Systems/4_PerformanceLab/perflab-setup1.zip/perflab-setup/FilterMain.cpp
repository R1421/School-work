#include <stdio.h>
#include "cs1300bmp.h"
#include <iostream>
#include <fstream>
#include "Filter.h"

using namespace std;

#include "rtdsc.h"

//
// Forward declare the functions
//
Filter * readFilter(string filename);
double applyFilter(Filter *filter, cs1300bmp *input, cs1300bmp *output);

int
main(int argc, char **argv)
{

  if ( argc < 2) {
    fprintf(stderr,"Usage: %s filter inputfile1 inputfile2 .... \n", argv[0]);
  }

  //
  // Convert to C++ strings to simplify manipulation
  //
  string filtername = argv[1];

  //
  // remove any ".filter" in the filtername
  //
  string filterOutputName = filtername;
  string::size_type loc = filterOutputName.find(".filter");
  if (loc != string::npos) {
    //
    // Remove the ".filter" name, which should occur on all the provided filters
    //
    filterOutputName = filtername.substr(0, loc);
  }

  Filter *filter = readFilter(filtername);

  double sum = 0.0;
  int samples = 0;

  for (int inNum = 2; inNum < argc; inNum++) {
    string inputFilename = argv[inNum];
    string outputFilename = "filtered-" + filterOutputName + "-" + inputFilename;
    struct cs1300bmp *input = new struct cs1300bmp;
    struct cs1300bmp *output = new struct cs1300bmp;
    int ok = cs1300bmp_readfile( (char *) inputFilename.c_str(), input);

    if ( ok ) {
      double sample = applyFilter(filter, input, output);
      sum += sample;
      samples++;
      cs1300bmp_writefile((char *) outputFilename.c_str(), output);
    }
  }
  fprintf(stdout, "Average cycles per sample is %f\n", sum / samples);

}

struct Filter *
readFilter(string filename)
{
  ifstream input(filename.c_str());

  if ( ! input.bad() ) {
    int size = 0;
    input >> size;
    Filter *filter = new Filter(size);
    int div;
    input >> div;
    filter -> setDivisor(div);
    for (int i=0; i < size; i++) {
      for (int j=0; j < size; j++) {
	int value;
	input >> value;
	filter -> set(i,j,value);
      }
    }
    return filter;
  }
}


double
applyFilter(struct Filter *filter, cs1300bmp *input, cs1300bmp *output)
{

  long long cycStart, cycStop;

  cycStart = rdtscll();

  output -> width = input -> width;
  output -> height = input -> height;

//################################################################################################################################
  int divisor = filter->getDivisor();
  int width = (input->width)-1;
  int height = (input->height)-1;


  for(int col = 1; col < width; col = col + 1) {
    for(int row = 1; row < height ; row = row + 3) {

        int value = 0;
        int value0 = 0;
        int value1 = 0;
        int value2 = 0;

        int value3 = 0; //Plane2
        int value4 = 0;
        int value5 = 0;
        int value6 = 0;

        int value7 = 0; //Plane3
        int value8 = 0;
        int value9 = 0;
        int value10 = 0;

        int filterSize = filter->getSize();
        for (int j = 0; j < filterSize; j++) {

          int i;
          int x = col + j -1;
          for (i = 0; i < filterSize; i += 3) {
            //Plane1
            value0 = value0 +  (input -> color[x][0][row + i - 1] * filter->get(i,j)) + (input->color[x][0][row + i] * filter->get(i+1,j)) + (input->color[x][0][row + i + 1] * filter->get(i+2, j));
            value4 = value4 +  (input -> color[x][0][row + i] * filter->get(i,j)) + (input->color[x][0][row + i +1] * filter->get(i+1,j)) + (input->color[x][0][row + i + 2] * filter->get(i+2, j));
            value7 = value7 +  (input -> color[x][0][row + i + 1] * filter->get(i,j)) + (input->color[x][0][row + i +2] * filter->get(i+1,j)) + (input->color[x][0][row + i + 3] * filter->get(i+2, j));


            //Plane2
            value1 = value1 +  (input -> color[x][1][row + i - 1] * filter->get(i,j)) + (input->color[x][1][row + i] * filter->get(i+1,j)) + (input->color[x][1][row + i + 1] * filter->get(i+2, j));
            value5 = value5 +  (input -> color[x][1][row + i] * filter->get(i,j)) + (input->color[x][1][row + i +1] * filter->get(i+1,j)) + (input->color[x][1][row + i + 2] * filter->get(i+2, j));
            value8 = value8 +  (input -> color[x][1][row + i + 1] * filter->get(i,j)) + (input->color[x][1][row + i +2] * filter->get(i+1,j)) + (input->color[x][1][row + i + 3] * filter->get(i+2, j));



            //Plane3
            value2 = value2 +  (input -> color[x][2][row + i - 1] * filter->get(i,j)) + (input->color[x][2][row + i] * filter->get(i+1,j)) + (input->color[x][2][row + i + 1] * filter->get(i+2, j));
            value6 = value6 +  (input -> color[x][2][row + i] * filter->get(i,j)) + (input->color[x][2][row + i +1] * filter->get(i+1,j)) + (input->color[x][2][row + i + 2] * filter->get(i+2, j));
            value9 = value9 +  (input -> color[x][2][row + i + 1] * filter->get(i,j)) + (input->color[x][2][row + i +2] * filter->get(i+1,j)) + (input->color[x][2][row + i + 3] * filter->get(i+2, j));

          }

          for(; i < filterSize; i++){
            value0 = value0 +  input -> color[x][0][row + i - 1] * filter->get(i,j);
            value4 = value4 + input->color[x][0][row+i] * filter->get(i,j);
            value7 = value7 + input->color[x][0][row+i+1] * filter->get(i,j);


            value1 = value1 +  input -> color[x][1][row + i - 1] * filter->get(i,j);
            value5 = value5 + input->color[x][1][row+i] * filter->get(i,j);
            value8 = value8 + input->color[x][1][row+i+1] * filter->get(i,j);


            value2 = value2 +  input -> color[x][2][row + i - 1] * filter->get(i,j);
            value6 = value6 + input->color[x][2][row+i] * filter->get(i,j);
            value9 = value9 + input->color[x][2][row+i+1] * filter->get(i,j);


          }
        }
        /*value = value0 + value1 + value2;
        value3 = value4 + value5 + value6;
        value7 = value8 + value9 + value10;*/

        value0 = value0 / divisor;
        value1 = value1 / divisor;
        value2 = value2 / divisor;

        value4 = value4 / divisor;
        value5 = value5 / divisor;
        value6 = value6 / divisor;

        value7 = value7 / divisor;
        value8 = value8 / divisor;
        value6 = value9 / divisor;

        if ( value0  < 0 ) { value0 = 0; }
        if ( value0  > 255 ) { value0 = 255; }

        if ( value1  < 0 ) { value1 = 0; }
        if ( value1  > 255 ) { value1 = 255; }

        if ( value2  < 0 ) { value2 = 0; }
        if ( value2  > 255 ) { value2 = 255; }


        if ( value4  < 0 ) { value4 = 0; }
        if ( value4  > 255 ) { value4 = 255; }

        if ( value5  < 0 ) { value5 = 0; }
        if ( value5  > 255 ) { value5 = 255; }

        if ( value6  < 0 ) { value6 = 0; }
        if ( value6  > 255 ) { value6 = 255; }


        if ( value7  < 0 ) { value7 = 0; }
        if ( value7  > 255 ) { value7 = 255; }

        if ( value8  < 0 ) { value8 = 0; }
        if ( value8  > 255 ) { value8 = 255; }

        if ( value9  < 0 ) { value9 = 0; }
        if ( value9  > 255 ) { value9 = 255; }

        output -> color[col][0][row] = value0;
        output -> color[col][1][row] = value1;
        output -> color[col][2][row] = value2;

        output -> color[col][0][row+1] = value4;
        output -> color[col][1][row+1] = value5;
        output -> color[col][2][row+1] = value6;

        output -> color[col][0][row+2] = value7;
        output -> color[col][1][row+2] = value8;
        output -> color[col][2][row+2] = value9;
      }

  }

//################################################################################################################################

  cycStop = rdtscll();
  double diff = cycStop - cycStart;
  double diffPerPixel = diff / (output -> width * output -> height);
  fprintf(stderr, "Took %f cycles to process, or %f cycles per pixel\n",
	  diff, diff / (output -> width * output -> height));
  return diffPerPixel;
}
