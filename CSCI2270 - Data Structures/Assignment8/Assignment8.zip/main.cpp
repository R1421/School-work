#include <iostream>
#include <stdlib.h>
#include "Graph.h"

using namespace std;

void displayMenu()
{
    cout<<"======Main Menu====="<<endl;
    cout<<"1. Print vertices"<<endl;
    cout<<"2. Find districts"<<endl;
    cout<<"3. Find shortest path"<<endl;
    cout<<"4. Find shortest distance"<<endl;
    cout<<"5. Extra credit"<<endl;
    cout<<"6. Quit"<<endl;
}

int main(int argc, char *argv[])
{

    Graph *g = new Graph("zombieCities.txt");

    string input;
    while(true){
        displayMenu();
        getline(cin, input);

        if(atoi(input.c_str()) == 1){
            //Print vertices
            g->displayGraph();
        }
        else if(atoi(input.c_str()) == 2){
            //Find Districts
        }
        else if(atoi(input.c_str()) == 3){
            //Find shortest path
        }
        else if(atoi(input.c_str()) == 4){
            //Find shortest distance
        }
        else if(atoi(input.c_str()) == 5){
            //Extra Credit
        }
        else if(atoi(input.c_str()) == 6){
            //Quit
            cout<<"Goodbye!"<<endl;
            break;
        }
        else{
            cout<<"Invalid input"<<endl;
        }

    }
}
