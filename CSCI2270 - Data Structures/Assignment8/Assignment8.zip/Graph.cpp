#include <iostream>
#include <queue>
#include <fstream>
#include <sstream>
#include <stdlib.h>
#include "Graph.h"

using namespace std;

Graph::Graph(string filename)
{
    //Constructor
    ifstream file;
    file.open(filename.c_str());

    if(file.fail()){
        cout<<"File could not be opened"<<endl;
    }
    else{
        string line;
        string word;

        //First create the list of vertices
        getline(file, line);
        stringstream ss(line);
        for(int i = 0; getline(ss, word, ','); i++){
            if(i != 0){
                addVertex(word);
                cout<<"Adding "<<word<<endl;
            }
        }

        //Now create the edges
        string name;
        int x = 0;
        while(!file.eof()){
            getline(file, line);
            cout<<endl<<line<<endl<<endl;;
            stringstream ss(line);
            for(int i = 0; getline(ss, word, ','); i++){
                cout<<word<<endl;
                if(i == 0){
                    name = word;
                }
                else if(atoi(word.c_str()) > 0){
                    if(i > x){
                        addEdge(name, vertices[i-1].name, atoi(word.c_str()));
                    }
                }
                //word = "";
            }
            x++;
        }

    }

}

Graph::~Graph()
{
    //Destructor
}

void Graph::addEdge(string name1, string name2, int weight)
{
    //add the edges
    for(int i = 0; i < vertices.size(); i++){
        if(vertices[i].name == name1){
            for(int j = 0; j < vertices.size(); j++){
                if(vertices[j].name == name2){
                    //both vertices have been found
                    //add the first adj vertex to the second's list
                    adjVertex av;
                    av.v = &vertices[i];
                    vertices[j].adj.push_back(av);
                    cout<<"Adding edge: "<<vertices[j].name<<"***"<<vertices[i].name<<endl;

                    //now add the second to the first's list
                    av.v = &vertices[j];
                    vertices[i].adj.push_back(av);
                    cout<<"Adding edge: "<<vertices[i].name<<"***"<<vertices[j].name<<endl;
                }
            }
        }
    }

}

void Graph::addVertex(string n)
{
    bool found = false;
    for(int i = 0; i < vertices.size(); i++){
        if(vertices[i].name == n){
            found = true;
            cout<<n<<" found."<<endl;
            break;
        }
    }
    if(!found){
        //create new vertex
        vertex v;
        v.name = n;
        v.visited = false;
        vertices.push_back(v);
    }
}

void Graph::displayGraph()
{
    for(int i = 0; i < vertices.size(); i++){
        cout<<vertices[i].name<<"-->";
        for(int j = 0; j < vertices[i].adj.size(); j++){
            if(j == 0){
                cout<<vertices[i].adj[j].v->name;
            }
            else{
                cout<<"***"<<vertices[i].adj[j].v->name;
            }
        }
        cout<<endl;
    }
}

void Graph::BFTraversal(string start)
{
    //Enter code
    vertex *s = NULL;
    for(int i = 0; i < vertices.size(); i++){
        if(vertices[i].name == start){
            s = &vertices[i];
            break;
        }
    }
    s->visited = true;
    cout<<s->name<<endl;
    queue<vector<adjVertex> > q;
    q.push(s->adj);

    while(q.size() > 0){
        vector<adjVertex> u = q.front();
        q.pop();
        for(int i = 0; i < u.size(); i++){
            if(u[i].v->visited == false){
                u[i].v->visited = true;
                cout<<u[i].v->name<<endl;
                q.push(u[i].v->adj);
            }
        }
    }
}
