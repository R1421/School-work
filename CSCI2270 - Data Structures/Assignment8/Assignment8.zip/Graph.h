#include <iostream>
#include <vector>

#ifndef GRAPH.H
struct vertex;

struct adjVertex
{
    vertex *v;
    int weight;
};

struct vertex
{
    std::string name;
    bool visited;
    std::vector<adjVertex> adj;
    int ID;
};

class Graph
{
private:
    std::vector<vertex> vertices;
protected:
public:
    Graph(std::string);
    ~Graph();
    void addEdge(std::string, std::string, int);
    void addVertex(std::string);
    void displayGraph();
    void BFTraversal(std::string);
};
#endif // GRAPH
