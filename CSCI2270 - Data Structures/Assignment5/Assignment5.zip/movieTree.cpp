#include <iostream>
#include "movieTree.h"

using namespace std;


MovieTree::MovieTree()
{
    root = new MovieNode;
    //root->title = "Something";
    cout<<root->title<<endl;
    root->parent = NULL;
    root->leftChild = NULL;
    root->rightChild = NULL;
}

MovieTree::~MovieTree()
{
    //Delete the tree
}

void MovieTree::printMovieInventory(MovieNode *node)
{
    //MovieNode *n = node;
    //if(node != NULL){
        if(node->leftChild != NULL){
            printMovieInventory(node->leftChild);
        }
        if(node->rightChild != NULL){
            printMovieInventory(node->rightChild);
        }
    //}
    cout<<node->title<<endl;
}

void MovieTree::addMovieNode(int ranking, string title, int releaseYear, int quantity)
{
    MovieNode *n = root;
    MovieNode *P = NULL;


    while(n != NULL){
        P = n;
        if(title < n->title){
            cout<<"Left"<<endl;
            cout<<title<<" is less than "<<n->title<<endl;
            n = n->leftChild;
        }
        else{
            cout<<title<<" is greater than "<<n->title<<endl;
            cout<<"Right"<<endl;
            n = n->rightChild;
        }
    }
    cout<<"Adding \""<<title<<"\" to tree!"<<endl<<endl;
    cout<<n<<" "<<P<<endl;
    n->title = title;
    n->leftChild = NULL;
    n->rightChild = NULL;


}
