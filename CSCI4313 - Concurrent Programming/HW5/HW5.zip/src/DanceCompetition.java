import java.util.concurrent.atomic.AtomicInteger;

public class DanceCompetition {
	private AtomicInteger girlCount;
	
	
	public DanceCompetition(){
		girlCount = new AtomicInteger(0);
	}
	
	public int getCount(){
		return girlCount.getAndIncrement();
	}
	
	public void push(int grade, int counter){
		
	}
}
