
public enum BattleResult {
	HomeWin, Tie, EnemyWin
}
