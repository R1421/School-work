import java.util.concurrent.atomic.AtomicReference;

public class LockFreeStack {
	/*
	 * Adapted from  Herlihy and Shavit - The Art of Multiprocessor Programming; Chapter 11.2
	 */
	private class Node{
		AtomicReference<Node> next;
		
		public Node(){
			next = new AtomicReference<Node>(null);
		}
	}
	AtomicReference<Node> top = new AtomicReference<Node>(null);
}
