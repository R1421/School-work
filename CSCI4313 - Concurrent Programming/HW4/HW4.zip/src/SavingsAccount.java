import java.util.Queue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.locks.*;

public class SavingsAccount {

	private int balance;
	private Queue priorityWithdrawls;
	private Queue withdrawls;
	private Lock lock;
	
	public class Withdrawl{
		public int k;
		
		public Withdrawl(int k){
			this.k = k;
		}
	}
	
	public SavingsAccount(){
		balance = 0;
		lock = new ReentrantLock();
		priorityWithdrawls = new LinkedBlockingQueue<Withdrawl>();
		withdrawls = new LinkedBlockingQueue<Withdrawl>();
	}
	
	public int getBalance(){
		return balance;
	}
	
	public void deposit(int k){
		lock.lock();
		balance += k;
		lock.unlock();
		System.out.println("Deposited: " + k);
	}
	
	public void withdraw(int k, boolean priority){
		boolean finished = false;
		Withdrawl withdrawl = new Withdrawl(k);
		if(priority){
			synchronized(priorityWithdrawls){
				priorityWithdrawls.put(withdrawl);
			}
		} else{
			synchronized(withdrawls){
				withdrawls.put(withdrawl);
			}
		}
		while(true){
			lock.lock();
			if(k <= balance && (priorityWithdrawls.peek() == null || priority)){
				balance -= k;
				finished = true;
			}
			lock.unlock();
			if(finished){
				break;
			} else {
				synchronized(withdrawl){
					try {
						withdrawl.wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		}
		if(priorityWithdrawls.peek() == null){
			if(withdrawls.peek() != null){
				withdrawls.peek().notify();
			}
		} else {
			priorityWithdrawls.peek().notify();
		}
		System.out.print("Total: " + getBalance() + "\tWithdrew: " + k + "\tPriority: " + priority);
	}
}
