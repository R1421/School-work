
public abstract class Barrier {
	protected int n;
	
	public Barrier(int n){
		this.n = n;
	}
	
	public void runBarrier(){
		//Maybe do something here
	}
}
