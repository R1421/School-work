import java.util.concurrent.atomic.AtomicInteger;

public class Barrier1 extends Barrier {
	private AtomicInteger counter;
	
	public Barrier1(int n){
		super(n);
		counter = new AtomicInteger(0);
	}
	
	public void runBarrier(){
		synchronized(counter){
			if(counter.incrementAndGet() != n){
				try {
					counter.wait();
				} catch (InterruptedException e) {
					//e.printStackTrace();
					return;
				}
			}
			counter.notifyAll();
			return;
		}
	}
}
